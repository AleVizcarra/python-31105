def funcion_paquete():
    print('Función paquete 2')