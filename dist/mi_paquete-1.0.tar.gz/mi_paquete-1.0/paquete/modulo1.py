def funcion_paquete():
    print('Hola soy la función de un paquete')